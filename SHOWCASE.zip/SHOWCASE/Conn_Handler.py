# IMPORTANT SETUP:
# This script requires the ODBC Driver for SQL Server to run properly, as well as all the libraries listed below
# In additon to this, the SQL Server this program will be connecting to must be configured to allow SQL Server authentication or this program most likely will be blocked from connecting 
import asyncio
import websockets
import pyodbc
import json
from datetime import datetime


# This is the information the program will use to connect to the SQL server,
# this is a simple approach used due to time constraints, and will probably need to be modified for use in the final system
SERVER="localhost\MSSQLSERVER01" #The IP address and name of the server you are connecting to, in the format <localhost>/<server name>
DATABASE="Spacebook" #The name of the database you are connecting to
USERNAME="JCH20" #The username you are connecting with, if you want a more sophisticated authentication approach this line will need to be moved elsewhere and adjusted to get the username from the frontend
PASSWORD="BigLongPassword" #The password you are connecting with, if you want a more sophisticated authentication approach this line will need to be moved elsewhere and adjusted to get the password from the frontend

# This string arranges the connection information into the appropriate order to be used to connect to the database server, will also need to be moved elsewhere when better authentication methods are implemented
ConnString=f"DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={SERVER};DATABASE={DATABASE};UID={USERNAME};PWD={PASSWORD};Encrypt=no" 



# This program exists to connect the frontend webpages to the backend database, and as such must handle two different kinds of connections, the first being HTML WebSockets and the second being an SQL connection via pyodbc
# To keep implementation simple this script handles all functionality within a single function, which is called everytime the script receives a WebSocket connection
# Upon connecting, the frontend webpages delivered along with this program are supposed to send a message in the format <Operation>@<Target_Table>, with potential third and fourth segments being included depending on operation
# These messages are used to create an appropriate SQL statement, which the script sends to the SQL server, after which it will send the retrieved data back to the frontend
# The @ signs are simply used as separators, to indicate to the program where to split messages into segments

#NOTE: I have left print statements I found helpful throughout development and testing commented out throughout the program, feel free to uncomment them for a glimpse into the functioning of the script
while True: # Ensures program contines running indefinitely, even in the event of errors
    try:
        async def conn_handle(websocket, path): # Called in the event the script receives a connection via HTML WebSockets, which are used by the frontend to communicate
            async for message in websocket:
                #print(message)
                args=message.split("@")
                conn = pyodbc.connect(ConnString)
                #print(f"Received message: {message}")
                cursor = conn.cursor()
                
                # Handles most of the frontend's requests for data from the backend
                # Receives messages in the format "pull@<Target_Table>@<Target_Columns>@<Where_Conditions>, the program will take this data segments and populate them into an SQL statement
                if args[0] == "pull":
                    SQL_QUERY = f"SELECT {args[2]} FROM {args[1]}"
                    if len(args) > 3 and args[3].strip():  # <- check for condition
                        temp=args[3].replace("\"", "")
                        SQL_QUERY += f" WHERE {temp}"
                    #print(SQL_QUERY)
                    cursor.execute(SQL_QUERY)
                    records = cursor.fetchall()

                    await websocket.send(f"pull@{args[1]}@")

                    row_lines = []
                    for r in records:
                        row_lines.append("@".join([str(field) for field in r]))
                    full_message = "\n".join(row_lines)
                    #print(full_message)
                    await websocket.send(full_message)
                
                
                #An older version of the pull function, which is only included to maintain functionality for 1 or 2 older pages which were completed before the change
                if(args[0]=="alt_pull"):
                    SQL_QUERY=f"SELECT {args[2]} FROM {args[1]};"
                    #print(SQL_QUERY)
                    cursor.execute(SQL_QUERY)
                    records=cursor.fetchall()
                    for r in records:
                        DatString=""
                        #print(r)
                        recordCount=0
                        for x in range(0, len(r)):
                            DatString=DatString+str(r[x])
                            if (recordCount+1)<len(r):
                                DatString=DatString+"@"
                            recordCount+=1
                        #print(DatString)
                        await websocket.send(f"{DatString}")
                
                
                # Handles all INSERT and UPDATE operations
                # Expects messages in the format push@<Target_Table>@<Data>, where <Data> is in JSON format, using column names as the key and the data for those columns as values, this JSON segment can contain any number of column-value pairs (not just one)
                # Also expects the first key-value pair in the message to be the primary key for any given table, primary key must be provided even if there is no intent to update it,
                # this is because this function uses an UPSERT approach that needs the primary key value to check whether a record already exists and decide whether it is updating or inserting
                if(args[0]=="push"):
                    #Cleans up message to get valid JSON
                    temp=args[2].replace("[", "")
                    temp=temp.replace("]", "")
                    #print(temp)
                    newmsg=json.loads(temp)
                    #print(newmsg)
                    #print(newmsg.keys())
                    
                    keystring="" #Used in INSERT operations to provide list of columns
                    keylist=[] #Used in UPDATE operations to provide list of columns
                    keycount=0 #Tracks for loop count to prevent extra comma being appended at end of data
                    Key="" #If message formated correctly, this should be set to the primary key of the table, which is also supposed to be the first key-value pair in of the JSON message
                    
                    #Pulls key values from the JSON <Data> segment and assigns them where they will be needed
                    for key in newmsg.keys():
                        keystring=keystring+key
                        if(keycount==0):
                            Key=key
                        if (keycount+1)<len(newmsg.keys()):
                            keystring=keystring+","
                        keycount+=1
                        keylist.append(key)
                    #print(keystring)
                        
                    valstring="" #Used in INSERT operations to provide list of values
                    vallist=[] #Used in UPDATE operations to provide list of values
                    valcount=0 #Tracks for loop count to prevent extra comma being appended at end of data
                    Value="" #If message formated correctly, this should be set to the value of the primary key of the table, which is also supposed to be the first key-value pair in of the JSON message
                    
                    #Pulls values from the JSON <Data> segment and assigns them where they will be needed
                    for value in newmsg.values():
                        #print(value)
                        if (valcount==0):
                            Value=value

                        if(value!="NULL" and value!="CURRENT_TIMESTAMP"):
                            tempval=f"\'{value}\'"
                        else:
                            tempval=f"{value}"
                            
                        if (valcount+1)<len(newmsg.values()):
                            tempval=tempval+", "
                        valstring=valstring+tempval
                        vallist.append(tempval)
                        valcount+=1
                        
                    #print(keystring)
                    #print(valstring)
                    
                    #Takes data from the two lists created above and combines them into appropriately formatted string for SQL UPDATE statement
                    UpdateString=""
                    for x in range(len(keylist)):
                        tempupdate=f"{keylist[x]} = {vallist[x]}"
                        UpdateString=UpdateString+tempupdate
                    
                    #SQL UPSERT statement, checks whether the data provided already correlates to an existing record, updates that record if it exists, otherwise inserts a new one
                    SQL_QUERY2=f"""
                    IF ((SELECT COUNT(*) FROM {args[1]} WHERE {Key}='{Value}' ) =1)
                    BEGIN
                    UPDATE {args[1]}
                    SET {UpdateString}
                    WHERE {Key}='{Value}';
                    END
                    ELSE
                    BEGIN
                    INSERT INTO {args[1]} ({keystring}) VALUES ({valstring});
                    END
                    """
                    #print(SQL_QUERY2)
                    cursor.execute(SQL_QUERY2)
                    conn.commit()
                
                
                #Handles all delete operations for the frontend, expects messages in the format "delete@<Target_Table>@<WHERE_CONDITION_VALUES>
                if(args[0]=="delete"):
                    SQL_QUERY3=f"DELETE FROM {args[1]} WHERE {args[2]}"
                    cursor.execute(SQL_QUERY3)
                    conn.commit()

                cursor.close()
                conn.close()

        
        start_server = websockets.serve(conn_handle, "192.168.140.152", 8080) #Sets program to listen on given port and IP, will need to be adjusted to work with your system, webpages will also need to be updated to send into this socket
        asyncio.get_event_loop().run_until_complete(start_server) #Opens the connection
        asyncio.get_event_loop().run_forever() #Keeps the connection open
        
        #This prevents any errors from stopping the program, and logs those errors to a log file
    except Exception as E:
        #print(E)
        f=open("ExceptionLog.txt", "a")
        Error=str(E)
        f.write(Error)
        f.close()

